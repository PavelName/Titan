const one = 'Naharis';
const two = 'Mormont';
const three = 'Sand';

console.log(`${one[2]}${two[1]}${three[3]}${two[4]}${two[2]}`)